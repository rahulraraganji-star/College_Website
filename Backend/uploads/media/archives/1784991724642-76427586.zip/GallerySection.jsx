import SectionHeading from "./SectionHeading";
import { useInView } from "../hooks/useInView";

const GalleryImage = ({ image, index }) => {
  const [ref, inView] = useInView();
  if (!image.image) return null;

  return (
    <div
      ref={ref}
      className={`break-inside-avoid mb-6 group transition-all duration-700 ease-out ${
        inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"
      }`}
      style={{ transitionDelay: inView ? `${Math.min(index, 6) * 70}ms` : "0ms" }}
    >
      <div className="overflow-hidden bg-[#2A2623]/5">
        <img
          src={image.image}
          alt={image.alt || ""}
          className="w-full object-cover transition-transform duration-700 ease-out group-hover:scale-[1.04]"
        />
      </div>
      {(image.caption || image.alt) && (
        <div className="pt-3">
          {image.caption && (
            <p className="font-['Inter'] font-medium text-sm text-[#2A2623]">{image.caption}</p>
          )}
          {image.alt && <p className="text-sm font-['Inter'] text-[#2A2623]/50 mt-0.5">{image.alt}</p>}
        </div>
      )}
    </div>
  );
};

const COLUMN_CLASSES = {
  2: "columns-1 md:columns-2",
  3: "columns-1 md:columns-2 lg:columns-3",
  4: "columns-2 lg:columns-4",
};

const GallerySection = ({ section }) => {
  const images = section.images || [];
  if (images.length === 0) return null;
  const columnsClass = COLUMN_CLASSES[section.columns] || COLUMN_CLASSES[3];

  return (
    <section className="pt-20 md:pt-24 border-t border-[#2A2623]/10">
      <SectionHeading eyebrow="Gallery" title={section.title} />
      <div className={`${columnsClass} gap-6`}>
        {images.map((image, i) => (
          <GalleryImage key={i} image={image} index={i} />
        ))}
      </div>
    </section>
  );
};

export default GallerySection;
