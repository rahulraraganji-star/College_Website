import Reveal from "./Reveal";

/**
 * The first RichText block immediately following the Hero is promoted
 * to an Editorial Introduction — the opening narrative of the page, set
 * in larger type than a standard body paragraph, at a narrower measure.
 *
 * If the CMS record includes a `quote` field, it's rendered as a pulled
 * highlight above the body copy. If it doesn't, nothing is invented —
 * that area is simply skipped.
 */
const EditorialIntro = ({ section }) => {
  if (!section?.content?.trim()) return null;

  return (
    <section className="max-w-[760px] mx-auto px-8 md:px-0 pt-16 md:pt-24">
      <Reveal>
        {section.heading && (
          <h2 className="font-['Fraunces'] text-[30px] md:text-[38px] font-medium text-[#2A2623] tracking-tight mb-8">
            {section.heading}
          </h2>
        )}

        {section.quote && (
          <blockquote className="border-l-2 border-[#C9A555] pl-6 mb-10">
            <p className="font-['Fraunces'] text-2xl md:text-[28px] leading-snug italic text-[#2A2623]/85">
              {section.quote}
            </p>
          </blockquote>
        )}

        <div className="whitespace-pre-wrap font-['Inter'] text-[19px] md:text-[20px] leading-9 text-[#2A2623]/75">
          {section.content}
        </div>
      </Reveal>
    </section>
  );
};

export default EditorialIntro;
