import Reveal from "./Reveal";

/**
 * Renders one editorial content block: a Heading paired with the
 * RichText paragraph(s) that immediately follow it in the CMS's section
 * order (the "ABOUT" / "VISION" / "MISSION" rhythm — heading owns its
 * content), or a standalone Heading / RichText when no pairing applies.
 * Always left-aligned at a comfortable reading width — never centered
 * floating text.
 */
const ContentSection = ({ heading, blocks = [] }) => {
  if (!heading && blocks.length === 0) return null;

  return (
    <Reveal>
      <div className="pt-16 md:pt-20 border-t border-[#2A2623]/10">
        {heading && (
          <h2 className="font-['Fraunces'] text-[28px] md:text-[36px] font-medium text-[#2A2623] tracking-tight mb-8">
            {heading}
          </h2>
        )}
        <div className="space-y-6">
          {blocks.map((block, i) => (
            <div
              key={i}
              className="whitespace-pre-wrap font-['Inter'] text-[17px] md:text-[18px] leading-8 text-[#2A2623]/75"
            >
              {block.content}
            </div>
          ))}
        </div>
      </div>
    </Reveal>
  );
};

export default ContentSection;
