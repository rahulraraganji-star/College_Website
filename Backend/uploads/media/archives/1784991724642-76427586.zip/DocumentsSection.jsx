import SectionHeading from "./SectionHeading";
import { FileText, ArrowUpRight } from "lucide-react";

const DocumentsSection = ({ section }) => {
  const documents = section.documents || [];
  if (documents.length === 0) return null;

  return (
    <section className="pt-20 md:pt-24 border-t border-[#2A2623]/10">
      <SectionHeading eyebrow="Documents" title={section.title} />
      <div className="divide-y divide-[#2A2623]/10 border-t border-b border-[#2A2623]/10">
        {documents.map((doc, i) => (
          <a
            key={i}
            href={doc.file}
            target="_blank"
            rel="noreferrer"
            className="group flex items-center gap-6 py-6 px-2 -mx-2 hover:bg-[#8A6B3F]/[0.04] transition-colors"
          >
            <FileText size={20} className="shrink-0 text-[#8A6B3F]" />
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-3 flex-wrap">
                <h3 className="font-['Inter'] font-medium text-[#2A2623]">{doc.title}</h3>
                {doc.category && (
                  <span className="font-['IBM_Plex_Mono'] text-[10px] uppercase tracking-wide text-[#8A6B3F] border border-[#8A6B3F]/30 px-2 py-0.5">
                    {doc.category}
                  </span>
                )}
              </div>
              {doc.description && (
                <p className="text-sm font-['Inter'] text-[#2A2623]/50 mt-1.5">{doc.description}</p>
              )}
            </div>
            <span className="flex items-center gap-1.5 font-['Inter'] text-sm uppercase tracking-wide text-[#8A6B3F] group-hover:text-[#C9A555] whitespace-nowrap transition-colors">
              Open
              <ArrowUpRight
                size={14}
                className="transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5"
              />
            </span>
          </a>
        ))}
      </div>
    </section>
  );
};

export default DocumentsSection;
