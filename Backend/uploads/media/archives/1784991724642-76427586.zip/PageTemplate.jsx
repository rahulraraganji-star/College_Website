import HeroSection from "./sections/HeroSection";
import PageKicker from "./sections/PageKicker";
import EditorialIntro from "./sections/EditorialIntro";
import ContentSection from "./sections/ContentSection";
import ListSection from "./sections/ListSection";
import TimelineSection from "./sections/TimelineSection";
import FacultySection from "./sections/FacultySection";
import GallerySection from "./sections/GallerySection";
import DocumentsSection from "./sections/DocumentsSection";
import EventListSection from "./sections/EventListSection";
import TableSection from "./sections/TableSection";
import EmbedSection from "./sections/EmbedSection";

// Unchanged from the original file — same section types, same
// required fields, same CMS data contract.
const hasData = (section) => {
  switch (section.type) {
    case "hero":
      return true;
    case "heading":
      return Boolean(section.text?.trim());
    case "richText":
      return Boolean(section.content?.trim());
    case "list":
      return Array.isArray(section.items) && section.items.length > 0;
    case "timeline":
      return Array.isArray(section.events) && section.events.length > 0;
    case "faculty-grid":
      return Array.isArray(section.departments) && section.departments.length > 0;
    case "gallery":
      return Array.isArray(section.images) && section.images.length > 0;
    case "table":
      return Array.isArray(section.rows) && section.rows.length > 0;
    case "documentList":
      return Array.isArray(section.documents) && section.documents.length > 0;
    case "eventList":
      return Array.isArray(section.events) && section.events.length > 0;
    case "embed":
      return Boolean(section.url);
    default:
      return false;
  }
};

// An editorial page uses a different measure for different content —
// this is what the brief calls out explicitly: hero/faculty/gallery run
// wide, editorial text and lists stay narrow, documents/tables/events
// sit in between.
const WIDTH_CLASSES = {
  content: "max-w-3xl",
  list: "max-w-3xl",
  timeline: "max-w-4xl",
  "faculty-grid": "max-w-7xl",
  gallery: "max-w-7xl",
  documentList: "max-w-5xl",
  eventList: "max-w-5xl",
  table: "max-w-5xl",
  embed: "max-w-5xl",
};

/**
 * Groups a flat CMS section list into editorial blocks:
 *  - a "heading" section absorbs any "richText" sections that
 *    immediately follow it, so they render together as one block with
 *    the heading owning its content (the ABOUT / VISION / MISSION
 *    rhythm from the brief);
 *  - a lone "richText" not preceded by a heading keeps its own
 *    optional `heading` field;
 *  - every other section type passes through untouched as its own
 *    group, still in its original CMS order.
 * This is purely a rendering-time grouping — nothing about the
 * underlying sections array is mutated or reordered.
 */
const buildEditorialGroups = (sections) => {
  const groups = [];
  let i = 0;
  while (i < sections.length) {
    const section = sections[i];
    if (section.type === "heading") {
      const blocks = [];
      let j = i + 1;
      while (j < sections.length && sections[j].type === "richText") {
        blocks.push(sections[j]);
        j++;
      }
      groups.push({ kind: "content", heading: section.text, blocks });
      i = j;
    } else if (section.type === "richText") {
      groups.push({ kind: "content", heading: section.heading || null, blocks: [section] });
      i++;
    } else {
      groups.push({ kind: section.type, section });
      i++;
    }
  }
  return groups;
};

const PageTemplate = ({ data }) => {
  if (!data) {
    return (
      <div className="min-h-[300px] flex items-center justify-center">
        <p className="font-['Inter'] text-[#2A2623]/40 text-lg">No content available</p>
      </div>
    );
  }

  const safeSections = Array.isArray(data.sections) ? data.sections : [];
  const heroSection = safeSections.find((section) => section.type === "hero");
  const remaining = safeSections.filter((section) => section.type !== "hero" && hasData(section));

  // The first RichText immediately after the Hero becomes the Editorial
  // Introduction — the page's opening narrative — rather than a grouped
  // content block.
  let intro = null;
  let groupable = remaining;
  if (remaining[0]?.type === "richText") {
    intro = remaining[0];
    groupable = remaining.slice(1);
  }

  const groups = buildEditorialGroups(groupable);
  const isEmpty = !heroSection && !intro && groups.length === 0;

  return (
    <div className="bg-[#F8F5F0]">
      {/* PAGE TITLE (no hero) */}
      {!heroSection && (
        <div className="px-8 md:px-16 pt-10">
          <PageKicker title={data.title} />
          <div className="w-10 h-[2px] bg-[#C9A555] mb-5" />
          <h1 className="font-['Fraunces'] text-4xl md:text-5xl font-medium text-[#2A2623] tracking-tight">
            {data.title}
          </h1>
        </div>
      )}

      {heroSection && <HeroSection section={heroSection} pageTitle={data.title} />}

      <main className="pb-28">
        {intro && <EditorialIntro section={intro} />}

        {isEmpty && (
          <div className="py-24 text-center">
            <p className="font-['Inter'] text-[#2A2623]/40">Content will be updated soon.</p>
          </div>
        )}

        {groups.map((group, index) => {
          const widthClass = WIDTH_CLASSES[group.kind] || "max-w-3xl";
          let content;

          switch (group.kind) {
            case "content":
              content = <ContentSection heading={group.heading} blocks={group.blocks} />;
              break;
            case "list":
              content = <ListSection section={group.section} />;
              break;
            case "timeline":
              content = <TimelineSection section={group.section} />;
              break;
            case "faculty-grid":
              content = <FacultySection section={group.section} />;
              break;
            case "gallery":
              content = <GallerySection section={group.section} />;
              break;
            case "documentList":
              content = <DocumentsSection section={group.section} />;
              break;
            case "eventList":
              content = <EventListSection section={group.section} />;
              break;
            case "table":
              content = <TableSection section={group.section} />;
              break;
            case "embed":
              content = <EmbedSection section={group.section} />;
              break;
            default:
              return null;
          }

          return (
            <div key={index} className={`${widthClass} mx-auto px-8 md:px-16`}>
              {content}
            </div>
          );
        })}
      </main>
    </div>
  );
};

export default PageTemplate;
