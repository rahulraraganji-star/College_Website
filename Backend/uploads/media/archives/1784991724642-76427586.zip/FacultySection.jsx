import SectionHeading from "./SectionHeading";
import Reveal from "./Reveal";

/**
 * NOTE ON DATA SHAPE: the original PageTemplate.jsx delegated faculty
 * member rendering to an imported <Card item={member} /> component that
 * wasn't provided, so its exact field names are unknown. This
 * FacultyCard below uses common CMS field names with fallbacks
 * (photo/image/avatar, title/role/position, bio/description). If your
 * real member objects use different keys, adjust the four accessors
 * marked below — everything else in this file is unaffected. Share the
 * original Card.jsx if you'd like this wired to the exact fields.
 */
const FacultyCard = ({ member }) => {
  const photo = member.photo || member.image || member.avatar;
  const name = member.name;
  const role = member.title || member.role || member.position;
  const bio = member.bio || member.description;
  const email = member.email;

  return (
    <div className="group">
      <div className="aspect-[4/5] bg-[#2A2623]/5 overflow-hidden">
        {photo ? (
          <img
            src={photo}
            alt={name || ""}
            className="h-full w-full object-cover grayscale-[15%] transition-all duration-500 group-hover:grayscale-0 group-hover:scale-[1.03]"
          />
        ) : (
          <div className="h-full flex items-center justify-center text-[#2A2623]/30 font-['Inter'] text-sm">
            No Photo
          </div>
        )}
      </div>
      <div className="pt-5">
        {name && <h4 className="font-['Fraunces'] text-lg font-medium text-[#2A2623]">{name}</h4>}
        {role && (
          <p className="mt-1 font-['IBM_Plex_Mono'] text-xs uppercase tracking-wide text-[#8A6B3F]">
            {role}
          </p>
        )}
        {bio && <p className="mt-3 font-['Inter'] text-sm leading-6 text-[#2A2623]/65">{bio}</p>}
        {email && (
          <a
            href={`mailto:${email}`}
            className="mt-3 inline-block font-['Inter'] text-sm text-[#2A2623]/50 hover:text-[#C9A555] transition-colors"
          >
            {email}
          </a>
        )}
      </div>
    </div>
  );
};

const FacultySection = ({ section }) => {
  const departments = section.departments || [];
  if (departments.length === 0) return null;

  return (
    <section className="pt-20 md:pt-24 border-t border-[#2A2623]/10">
      <SectionHeading eyebrow="Faculty" title={section.title} />
      <div className="space-y-16">
        {departments.map((department, dIndex) => (
          <Reveal key={department.id || dIndex}>
            <div className="space-y-8">
              <div className="flex items-center gap-4 border-b border-[#2A2623]/10 pb-3">
                <span className="w-6 h-[2px] bg-[#C9A555]" />
                <h3 className="font-['Fraunces'] text-2xl font-medium text-[#2A2623]">
                  {department.name}
                </h3>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-x-8 gap-y-12">
                {(department.members || []).map((member, mIndex) => (
                  <FacultyCard key={member.id || mIndex} member={member} />
                ))}
              </div>
            </div>
          </Reveal>
        ))}
      </div>
    </section>
  );
};

export default FacultySection;
