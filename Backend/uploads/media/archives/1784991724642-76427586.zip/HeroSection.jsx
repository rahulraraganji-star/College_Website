import { useEffect, useState } from "react";
import { ArrowRight } from "lucide-react";
import PageKicker from "./PageKicker";

const HERO_HEIGHT_CLASSES = {
  small: "min-h-[38vh]",
  medium: "min-h-[48vh]",
  large: "min-h-[60vh]",
  fullscreen: "min-h-[86vh]",
};

const HERO_ALIGN_CLASSES = {
  left: "items-start text-left",
  center: "items-center text-center",
  right: "items-end text-right",
};

/**
 * Cinematic hero, content weighted toward the bottom of the frame like
 * an editorial cover rather than centered like a slide. Two variants,
 * same as the original: a full image banner when `section.background`
 * is set, and a quiet title block (on the page background) when it
 * isn't — e.g. while a page is still being drafted in the CMS.
 */
const HeroSection = ({ section, pageTitle }) => {
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    const frame = requestAnimationFrame(() => setLoaded(true));
    return () => cancelAnimationFrame(frame);
  }, []);

  const hasHeroContent =
    section.heading || section.subheading || section.background?.url || section.buttonText;

  if (!hasHeroContent) return null;

  const hasImage = Boolean(section.background?.url);
  const alignClass = HERO_ALIGN_CLASSES[section.alignment] || HERO_ALIGN_CLASSES.center;
  const revealClass = `transition-all duration-1000 ease-out ${
    loaded ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"
  }`;

  if (!hasImage) {
    return (
      <div className="px-8 md:px-16 pt-10 md:pt-14">
        <div className={`flex flex-col ${alignClass} ${revealClass}`}>
          <PageKicker title={pageTitle} />
          <div className="w-12 h-[2px] bg-[#C9A555] mb-6" />
          {section.heading && (
            <h1 className="font-['Fraunces'] text-[38px] md:text-[52px] leading-[1.08] font-medium text-[#2A2623] tracking-tight max-w-4xl">
              {section.heading}
            </h1>
          )}
          {section.subheading && (
            <p
              className={`mt-6 font-['Inter'] text-lg md:text-xl leading-8 max-w-2xl text-[#2A2623]/65 ${
                section.alignment === "center" ? "mx-auto" : ""
              }`}
            >
              {section.subheading}
            </p>
          )}
          {section.buttonText && (
            <a
              href={section.buttonLink || "#"}
              className="group inline-flex items-center gap-2 justify-center mt-9 px-8 py-3.5 font-['Inter'] text-sm tracking-wide uppercase border border-[#8A6B3F] text-[#2A2623] hover:bg-[#2A2623] hover:text-[#F8F5F0] hover:border-[#2A2623] transition-colors duration-300 w-fit"
            >
              {section.buttonText}
              <ArrowRight size={16} className="transition-transform group-hover:translate-x-1" />
            </a>
          )}
        </div>
      </div>
    );
  }

  const heightClass = HERO_HEIGHT_CLASSES[section.height] || HERO_HEIGHT_CLASSES.medium;
  const overlayOpacity = (section.overlay ?? 40) / 100;

  return (
    <section className={`relative overflow-hidden flex flex-col justify-end ${heightClass}`}>
      <img
        src={section.background.url}
        alt={section.background.alt || ""}
        className="absolute inset-0 h-full w-full object-cover scale-[1.02]"
        style={{ objectPosition: section.backgroundPosition || "center" }}
      />
      {/* Gradient weighted toward the bottom so bottom-aligned text
          always sits on a legible dark field, regardless of the image. */}
      <div
        className="absolute inset-0"
        style={{
          background: `linear-gradient(180deg,
            rgba(15,13,11,${overlayOpacity * 0.3}) 0%,
            rgba(15,13,11,${overlayOpacity * 0.8}) 55%,
            rgba(15,13,11,${overlayOpacity * 1.5}) 100%)`,
        }}
      />

      <div className="relative z-10 w-full">
        <div
          className={`w-full max-w-7xl mx-auto flex flex-col px-8 md:px-16 lg:px-24 pt-24 pb-14 md:pb-20 ${alignClass} ${revealClass}`}
        >
          <PageKicker title={pageTitle} dark />
          <div className="w-14 h-[2px] bg-[#C9A555] mb-6" />
          {section.heading && (
            <h1 className="font-['Fraunces'] text-[40px] md:text-[56px] lg:text-[64px] font-medium leading-[1.05] tracking-tight max-w-4xl text-[#F8F5F0]">
              {section.heading}
            </h1>
          )}
          {section.subheading && (
            <p
              className={`mt-6 font-['Inter'] text-lg md:text-xl leading-8 max-w-2xl text-[#F8F5F0]/80 ${
                section.alignment === "center" ? "mx-auto" : ""
              }`}
            >
              {section.subheading}
            </p>
          )}
          {section.buttonText && (
            <a
              href={section.buttonLink || "#"}
              className="group inline-flex items-center gap-2 justify-center mt-9 px-8 py-3.5 font-['Inter'] text-sm tracking-wide uppercase border border-[#C9A555] text-[#F8F5F0] hover:bg-[#C9A555] hover:text-[#2A2623] transition-colors duration-300 w-fit"
            >
              {section.buttonText}
              <ArrowRight size={16} className="transition-transform group-hover:translate-x-1" />
            </a>
          )}
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
