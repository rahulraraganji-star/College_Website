import SectionHeading from "./SectionHeading";
import { CalendarDays } from "lucide-react";

const EventListSection = ({ section }) => {
  const events = section.events || [];
  if (events.length === 0) return null;

  return (
    <section className="pt-20 md:pt-24 border-t border-[#2A2623]/10">
      <SectionHeading eyebrow="Events" title={section.title} />
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {events.map((event, i) => (
          <div
            key={i}
            className="border border-[#2A2623]/10 bg-white/40 p-7 hover:border-[#C9A555]/50 transition-colors"
          >
            {event.date && (
              <p className="flex items-center gap-2 font-['IBM_Plex_Mono'] text-xs uppercase tracking-wide text-[#8A6B3F]">
                <CalendarDays size={13} />
                {event.date}
              </p>
            )}
            <h3 className="mt-3 font-['Fraunces'] text-xl font-medium text-[#2A2623]">{event.title}</h3>
            {event.description && (
              <p className="mt-3 font-['Inter'] text-[#2A2623]/70 leading-7">{event.description}</p>
            )}
          </div>
        ))}
      </div>
    </section>
  );
};

export default EventListSection;
